var express = require('express');
var router = express.Router();
var connection  = require('../lib/db');
 
/* GET contact page. */
router.get('/', function(req, res, next) {
    connection.query('SELECT * FROM agencies', function(err, result1) {
        connection.query('SELECT * FROM agents', function(err, result2) {
            res.render('contact', { data : result1, data2: result2 });
        });
    });
});
 
module.exports = router;