var express = require('express');
var router = express.Router();
var connection  = require('../lib/db');
 
// SHOW REGISTER FORM
router.get('/', function(req, res, next){    
    // render to views/register.ejs
    res.render('register', {
     
    })
})
 
module.exports = router;